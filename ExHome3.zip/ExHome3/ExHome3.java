
package ex.home3;

import java.util.Scanner;
import static jdk.nashorn.tools.ShellFunctions.input;


public class ExHome3 {

    
    public static void main(String[] args) {

   Scanner sc = new Scanner(System.in);
   double w;
   System.out.println("Give me your weghit");
   w = input.nextInt();
   
   if (w>=30){System.out.println("obese");}
   else if (w>25.0){System.out.println("over weight!");}
    else if (w>=18.5){System.out.println("Normal!");}
   else {System.out.println("under weight");}


    }
    
}
