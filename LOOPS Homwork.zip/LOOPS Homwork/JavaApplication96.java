

package javaapplication96;

import java.util.Scanner;


public class JavaApplication96 {

    
    public static void main(String[] args) {

    Scanner input = new Scanner(System.in);
            int randomNamber = (int)(Math.random()*100);
            System.out.println("Guess th number between 0 and 100");
            while(true){int guess = input.nextInt();
            if(guess < randomNamber){System.out.println("too low try again");
            }else if(guess> randomNamber){System.out.println("too high try again");
            
            }else{System.out.println("corret! the number was"+ randomNamber);
            break;
            }

    }
    
}
