
package javaapplication88;

import java.util.Scanner;

public class JavaApplication88 {

    
    public static void main(String[] args) {
        
    
        int num1 = (int)(Math.random()*10);
        int num2 = (int)(Math.random()*10);
        int sum = num1 + num2;
        
        System.out.println("num1:" + num1);
         System.out.println("num2:" + num2);
         
        while(true){System.out.println("enter your gues");
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if(answer == sum){System.out.println("your gues is right");
        break;}
        else{ 
        
        System.out.println("your gues is wrong");}
        }
    }
        
         
        
    
    
        
        
        
        

    }

    private static void close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static void Close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
