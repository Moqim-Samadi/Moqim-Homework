package nestedloopsinjava;


public class NestedLoopsInJava {


    public static void main(String[] args) {

    for(int j = 0; j <= 10; j++){
        for(int i = 2; i <= 10; i++){
            System.out.println(i + "x" + j + "=" + (i * j));
            
        }
    }

    }
    
}
