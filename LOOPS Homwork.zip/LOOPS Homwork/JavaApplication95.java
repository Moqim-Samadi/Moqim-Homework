package javaapplication95;

import java.util.Scanner;

public class JavaApplication95 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int num1 = (int)(Math.random()*10);
        int num2 = (int)(Math.random()*10);
        System.out.println("what is "+num1+"+"+num2+"?");
        while(true){int answer = input.nextInt();
        if(answer == num1 + num2){ System.out.println("correct!");
        break;}
        
        
           
            
        else{System.out.println("incorrect!");
        

    }
