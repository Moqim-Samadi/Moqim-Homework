
package javaapplication91;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.year;




public class JavaApplication91 {

  
    public static void main(String[] args) {

        
      double tuition = 10000;
      double purpose = 2*tuition;
      double percentage = 0.07;
      int year = 0;
      while(tuition < purpose){tuition += tuition * percentage ;
      year ++;
      
      }System.out.println("it will take = " + year + "s to double the tuition");
      
        
       
    
   
    
    }
        
    }
    
}
