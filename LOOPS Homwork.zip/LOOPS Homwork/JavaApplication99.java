
package javaapplication99;

import java.util.Scanner;

public class JavaApplication99 {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int correctAnswers = 0;
        for(int i = 0; i < 5; i++){
            int num1 = (int)(Math.random()*50);
            int num2 = (int)(Math.random()*50);
            System.out.println("what is " + num1 +"-"+ num2+"?");
            int answer = input.nextInt();
            if(answer == num1 - num2){correctAnswers++;
        }System.out.println("you got "+ correctAnswers+" out of 5 correct!");
        

    }
    
}
