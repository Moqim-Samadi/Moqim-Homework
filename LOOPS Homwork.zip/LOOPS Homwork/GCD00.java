package gcd;

import java.util.Scanner;

public class GCD {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter your first number to find thier GCD");
        int a = input.nextInt();
        System.out.println("Enter your second nuber to find thier GCD");
        int b = input.nextInt();
        int minimum = Math.min(a, b);
        int GCD = 1;
        for (int i = 1; 1 <= minimum; i++) {
            if (a % i == 0 && b % i == 0) {
                GCD = i;
            }
            System.out.println("The GCD between " + a + " and " + b + "is:\n" + GCD);

        } input.close();

    
}
