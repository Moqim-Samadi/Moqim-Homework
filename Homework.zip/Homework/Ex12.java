package ex.pkg12;

import java.util.Scanner;

public class Ex12 {

    
    public static void main(String[] args) {



   final double PI = 3.14;
   Scanner input = new Scanner(System.in);
   double r = input.nextDouble();
   double area;
   area = PI*r*r;
   System.out.println(area);



    }
    
}
