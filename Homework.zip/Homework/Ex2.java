package ex.pkg2;


public class Ex {

    
    public static void main(String[] args) {

  final double PI = 3.14159;
        System.out.println(" the value of PI is " + PI);


    }
    
}
