
package ex.pkg4;

public class Ex4 {

   
    public static void main(String[] args) {

   char letter = 'A';
   int num = 100;
   



    }
    
}
