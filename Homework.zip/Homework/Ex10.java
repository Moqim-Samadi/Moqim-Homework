package ex.pkg10;


public class Ex10 {

    
    public static void main(String[] args) {

    boolean a = true;
    boolean b = false;
    
     System.out.println(a&&b);
      System.out.println(a||b);
       System.out.println(!a);
        System.out.println(!b);




    }
    
}
