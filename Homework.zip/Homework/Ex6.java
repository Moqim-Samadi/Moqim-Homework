package ex.pkg6;


public class Ex6 {

    
    public static void main(String[] args) {

   double d = 9.7;
   int i = (int)(d);
   
   System.out.println(d);
   System.out.println(i);

   

    }
    
}
