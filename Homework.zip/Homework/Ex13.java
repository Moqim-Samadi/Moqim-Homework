
package ex.pkg13;

import java.util.Scanner;


public class Ex13 {

   
    public static void main(String[] args) {


   Scanner sc = new Scanner(System.in);
   double fahreheit;
        fahreheit= scanner.nextDouble();
   double celsius = (5/9d)*(fahreheit-32);  
        System.out.println(celsius);



    }
    
}
