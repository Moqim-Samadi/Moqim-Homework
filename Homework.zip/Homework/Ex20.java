
package ex.pkg20;

import java.util.Scanner;


public class Ex20 {

    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
    System.out.println("Enter the first number:");
    String input = scanner.nextline();
    if (isPalidrome(input)){System.out.println("'"+input+"is a palindrome.");}
    else {System.out.println("'"+input+"is a palindrome.");}






    }

    private static boolean isPalidrome(String input) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
