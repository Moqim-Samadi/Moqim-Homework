
package ex.pkg1;

public class Ex1 {

        public static void main(String[] args) {

        int x = 5;
        System.out.println(x);
        
        
        
        
        }
    
}
