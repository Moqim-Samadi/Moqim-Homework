

package ex.pkg19;

import java.util.Scanner;
import static jdk.nashorn.tools.ShellFunctions.input;



public class Ex19 {

    
    public static void main(String[] args) {


       Scanner sc = new Scanner(System.in);
    System.out.println("Enter the first number:");
    int num1 = input.nextInt();
    System.out.println("Enter the second number:");
    int num2 = input.nextInt();
     System.out.println("Enter the third number:");
    int num3 = input.nextInt();
    
    int max = (num1>num2)?((num1>num3)? num1 : num3): ((num2>num3)? num2 : num3);
        System.out.println("the max number is"+max);
    
    








    }
    
}
