package ex.pkg7;

public class Ex7 {

        public static void main(String[] args) {

        int x = 15;
        int y = 4;
        int remainder = x%y;
        System.out.println(remainder);
        
        
        
        }
    
}
