package ex.pkg9;

public class Ex9 {

    
    public static void main(String[] args) {


    int x = 10;
    int y = 20;
    
    
    System.out.println(20>10);
     System.out.println(20<10);
      System.out.println(20>=10);
       System.out.println(20<=10);
        System.out.println(20!=10);
    



    }
    
}
