
package ex.pkg17;

import java.util.Scanner;
import static jdk.nashorn.tools.ShellFunctions.input;

public class Ex17 {

   
    public static void main(String[] args) {

     Scanner sc = new Scanner(System.in);
     int number;
        System.out.println("Enter an integer:");
        number = input.nextInt();
        
        boolean isPrime = checkPrime(number);
        if (isPrime ){System.out.println(number+"is a prime number");}
        else {System.out.println(number+"is  not a prime number");
        input.close();
        }

    }

    @SuppressWarnings("empty-statement")
    private static boolean checkPrime(int number) {
        
        {
        if (number <= 1){return false ; }
        for (int i = 2; i <=Math.sqrt(number); i++)
        } 
        
        
if (number % i == 0)
{ return false ;}
{ return false;{  
        
        { return true;{
