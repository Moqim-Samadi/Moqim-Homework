
package ex.pkg18;

import static java.lang.Integer.reverse;
import java.util.Scanner;
import static jdk.nashorn.tools.ShellFunctions.input;


public class Ex18 {

  
    public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the integer");
    int number = input.nextInt();
    int o = 0;
    int reversednumber =o;
    while (number !=0){int digit = number%10;
    reversednumber = reversednumber*10+digit;
    number/=10;
    System.out.println("revers number:"+reversednumber);
    }
        
        

    }
    
    
    
    
    
    
    
    
    
    
    

    private static class input {

        private static int nextInt() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
       
        public input() {
        }
    }
    
}
