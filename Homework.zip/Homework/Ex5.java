
package ex.pkg5;


public class Ex5 {

        public static void main(String[] args) {

      String firstName = "Moqim";
      String lastName = "Samadi";
      String fullName = firstName+lastName;
      System.out.println(fullName);
        
        
        
        }
    
}
