package ex.pkg8;

public class Ex8 {

    
    public static void main(String[] args) {

    int x = 5;
    System.out.println(x);
    
    
    x += 3;
    System.out.println(x);
        
    
    x -= 2;
    System.out.println(x);
    
    
    x *= 4;
    System.out.println(x);
    
    
    x /= 5;
    System.out.println(x);
    
    x %= 3;
    System.out.println(x);







    }
    
}
